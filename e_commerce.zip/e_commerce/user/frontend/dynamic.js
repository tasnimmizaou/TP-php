document.addEventListener("DOMContentLoaded", function() {
    // Select the icons
    var loginIcon = document.querySelector('.login i');
    var registerIcon = document.querySelector('.register i');
    var logoutIcon = document.querySelector('.logout i');
    var loggedInUserIcon = document.querySelector('.logged_user  i ');
    var cartIcon = document.querySelector('.cart i ');

    /*// Example manipulation: Change color of the icons
    loginIcon.style.color = 'green';
    registerIcon.style.color = 'blue';
    logoutIcon.style.color ='red';
    loggedInUserIcon.style.color = 'orange';
    cartIcon.style.color = 'yellow';*/
    
  

});

